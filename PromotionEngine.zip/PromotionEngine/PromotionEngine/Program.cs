﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class PromotionEngine
    {
        class Promotion
        {

            public int Quantity { get; set; }
            public int UnitPrice { get; set; }
        }

        static Dictionary<string, int> SKU_PRICE = new Dictionary<string, int>();
        static Dictionary<string, Promotion> Promotion_detail = new Dictionary<string, Promotion>();

        static void Main(string[] args)
        {

            Promotion_detail.Add("A", new Promotion() { Quantity = 3, UnitPrice = 130 });
            Promotion_detail.Add("B", new Promotion() { Quantity = 2, UnitPrice = 45 });
            Promotion_detail.Add("C", new Promotion() { Quantity = 1, UnitPrice = 20 });
            Promotion_detail.Add("D", new Promotion() { Quantity = 1, UnitPrice = 15 });
            Promotion_detail.Add("CD", new Promotion() { Quantity = 2, UnitPrice = 30 });
            //Promotion_detail.Add("DC", new Promotion() { Quantity = 2, UnitPrice = 30 });

            SKU_PRICE.Add("A", 50);
            SKU_PRICE.Add("B", 30);
            SKU_PRICE.Add("C", 20);
            SKU_PRICE.Add("D", 15);

            Dictionary<string, int> purchases = new Dictionary<string, int>();
            purchases.Add("A", 3);
            purchases.Add("B", 5);
            purchases.Add("C", 1);
            purchases.Add("D", 1);

            int res = 0;
            string cd_sku = "";
            int cd_unit = 0;
            foreach (KeyValuePair<string, int> p in purchases)
            {
                if (p.Key != "C" && p.Key != "D")
                {
                    res += RuleEngine(p.Key, p.Value, purchases);
                }
                else
                {
                    cd_sku += p.Key;
                    cd_unit += p.Value;

                }
            }
            res += RuleEngine(cd_sku, cd_unit, purchases);

        }
        static int RuleEngine(string SKUId, int units, Dictionary<string, int> purchases)
        {
            Promotion promotion = Promotion_detail[SKUId];
            int rem = 0;
            int promotionPrice = 0;
            int total_price = 0;
            switch (SKUId)
            {

                case "A":
                case "B":
                    {
                        if (units >= promotion.Quantity)
                        {
                            rem = units % promotion.Quantity;
                            promotionPrice = ((units - rem) / promotion.Quantity) * promotion.UnitPrice;
                            total_price = promotionPrice + (rem * SKU_PRICE[SKUId]);
                        }
                        else
                        {
                            total_price = units * SKU_PRICE[SKUId];
                        }
                    }
                    break;

                case "CD":
                case "C":
                case "D":
                    {
                        int c_price = units * SKU_PRICE["C"];
                        int d_price = units * SKU_PRICE["D"];

                        int c_count = 0;
                        int d_count = 0;
                        if (purchases.ContainsKey("C"))
                        {
                            c_count = purchases["C"];
                        }
                        if (purchases.ContainsKey("D"))
                        {
                            d_count = purchases["D"];
                        }

                        if (c_count > d_count)
                        {
                            rem = (c_count - d_count);
                            total_price = rem * SKU_PRICE["C"];
                        }
                        else if (c_count < d_count)
                        {
                            rem = (d_count - c_count);
                            total_price = rem * SKU_PRICE["D"];
                        }
                        else if (c_count == d_count)
                        {
                            rem = c_count;
                        }
                        if (c_count >= 1 && d_count >= 1)
                        {
                            total_price = ((rem) * promotion.UnitPrice) + total_price;
                        }
                    }
                    break;
                default:
                    break;

            }
            return total_price;
        }
    }
}